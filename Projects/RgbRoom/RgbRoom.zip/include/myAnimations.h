#include <FastLED.h>
#include <cmath>
#include <iostream>
#include <vector>

#ifndef MY_ANIMATIONS
#define MY_ANIMATIONS

class Pulse {
private:
    int ledCount;
    int length; // length of impulse
    float step; // length of step forwards a pulse runs in a tick
    float position; // position of pulse
    std::vector<CRGB> buffer;
    CRGB color;

public:
    bool done;

    // Constructor
    Pulse(int led_count = 1, int pulseLength = 1, float stepSize = 1.0, float spawnPosition = 0.0, CRGB pulseColor = CRGB::Black)
        : ledCount(led_count), length(pulseLength), step(stepSize), position(spawnPosition), color(pulseColor), buffer(length), done(false) {
        std::cout << "### creating new Pulse ### at address: " << this << std::endl;
    }

    //Pulse(Pulse& other) = delete;
    //Pulse &operator=(Pulse& other) = delete;

    // Destructor
    ~Pulse() {
        std::cout << "Pulse destroyed at address: " << this << std::endl;
    }

    // Update animation and return true if animation is done and can be deleted
    bool update(CRGB* leds, int* map) {
        if (done || position >= ledCount) {
            done = true;
            return true;
        }

        // Changing color
        int i_last = -1;
        int buffer_i = 0;
        for (float f = position; f < position + length; f += step) {
            int i = static_cast<int>(std::floor(f));
            if (i >= 0 && i < ledCount && i_last != i) {
                i_last = i;
                int i_mapped = map[i];
                if (i_mapped >= 0 && i_mapped < ledCount) {
                    buffer[buffer_i] = leds[i_mapped];
                    buffer_i++;
                    leds[i_mapped] = color;
                }
            }
        }

        FastLED.show();

        // Undoing changes to LED array
        i_last = -1;
        buffer_i = 0;
        for (float f = position; f < position + length; f += step) {
            int i = static_cast<int>(std::floor(f));
            if (i >= 0 && i < ledCount && i_last != i) {
                int i_mapped = map[i];
                if (i_mapped >= 0 && i_mapped < ledCount) {
                    leds[i_mapped] = buffer[buffer_i];
                    buffer_i++;
                }
            }
        }

        position += step;
        std::cout << "p: " << position << std::endl;
        return false;
    }
};

class PulseManager {
private:
    CRGB* leds; // LED array to perform animation on
    int* map; // Defines custom order of LEDs
    std::vector<Pulse> pulses; // Container for holding multiple pulses

public:
    PulseManager(CRGB* ledArray, int* ledMapping)
        : leds(ledArray), map(ledMapping) {
    }

    ~PulseManager() {
        std::cout << "PulseManager destroyed at address: " << this << std::endl;
    }

    void spawnPulse(int led_count, int pulseLength = 1, float stepSize = 1, float spawnPosition = 0.0, CRGB pulseColor = CRGB::Black) {
        pulses.emplace_back(led_count, pulseLength, stepSize, spawnPosition, pulseColor);
    }

    /*void update() {
        for (auto it = pulses.begin(); it != pulses.end(); ) {
            if (it->update(leds, map)) {
                std::cout << "Removing completed Pulse." << std::endl;
                it = pulses.erase(it);
            } else {
                ++it;
            }
        }
    }*/

    void update() {
        for(int i = 0;i<pulses.size();){
            bool var = pulses.at(i).update(leds, map);
            std::cout << "var: " << var << std::endl;
            if(var){
                pulses.erase(pulses.begin()+i);
            }else{
                i++;
            }
        }
    }
};

#endif
