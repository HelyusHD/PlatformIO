#ifndef NETWORK_CONFIG
#define NETWORK_CONFIG
    #define HOME_NETWORK_PASSWORD "85505796012028034369"
    #define HOME_NETWORK_SSID "Andre Thullen"

    #define ESP_NETWORK_PASSWORD  "21345678"
    #define ESP_NETWORK_SSID "ESP32_Network"

    #define CLIENT_01 "192.168.4.2"
    #define CLIENT_02 "192.168.4.3"
    #define CLIENT_03 "192.168.4.4"
#endif
